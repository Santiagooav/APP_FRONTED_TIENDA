import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonContent, IonHeader, IonTitle, IonToolbar, IonCol, IonRow, IonCard, IonGrid, IonCardHeader, IonCardTitle, IonCardContent, IonButtons, IonButton, IonIcon, IonBackButton } from '@ionic/angular/standalone';
import { ProductoService } from '../../servicios/producto';
import { ModalController, ToastController, AlertController } from '@ionic/angular/standalone';

@Component({
  selector: 'app-catalogo',
  templateUrl: './catalogo.page.html',
  styleUrls: ['./catalogo.page.scss'],
  standalone: true,
  imports: [IonBackButton, IonIcon, IonButtons, IonCardContent, IonCardTitle, IonCardHeader, IonGrid, IonCard, IonRow, IonCol, IonContent, IonHeader, IonTitle, IonToolbar, CommonModule, FormsModule]
})
export class CatalogoPage implements OnInit {
  productos: any[] = [];
  baseUrl: string = 'http://localhost:3000'; // Dirección de tu backend de Node

  constructor(private productoService: ProductoService, private modalCtrl: ModalController) { }

  ngOnInit() {
    this.obtenerCatalogo();
  }

  cerrar() { this.modalCtrl.dismiss(); }

  obtenerCatalogo() {
    this.productoService.getProductos().subscribe({
      next: (data: any) => {
        // Si el backend responde con un objeto { cantidad, data }, extraemos el arreglo.
        // Si responde directamente con el arreglo, lo asignamos de forma directa.
        this.productos = data.data ? data.data : data;
      },
      error: (err) => {
        console.error('Error al mapear el catálogo de productos:', err);
      }
    });
  }
}
