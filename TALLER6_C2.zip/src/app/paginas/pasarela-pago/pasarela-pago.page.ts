import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { 
  IonContent, IonHeader, IonTitle, IonToolbar, IonBackButton, 
  IonButtons, IonItem, IonLabel, IonInput, IonButton, ToastController 
} from '@ionic/angular/standalone';
import { Ipedido } from '../../interfaces/pedidos';

@Component({
  selector: 'app-pasarela-pago',
  templateUrl: './pasarela-pago.page.html',
  styleUrls: ['./pasarela-pago.page.scss'],
  standalone: true,
  imports: [
    IonContent, IonHeader, IonTitle, IonToolbar, IonBackButton, 
    IonButtons, IonItem, IonLabel, IonInput, IonButton, CommonModule, FormsModule
  ]
})
export class PasarelaPagoPage implements OnInit {
  pedido: Ipedido | null = null;
  total = 0;
  pago = { nombre: '', tarjeta: '', exp: '', cvv: '' };

  constructor(private router: Router, private toastCtrl: ToastController) {
    const navigation = this.router.getCurrentNavigation();
    if (navigation?.extras.state && navigation.extras.state['pedido']) {
      this.pedido = navigation.extras.state['pedido'];
      if (this.pedido) {
        this.total = this.pedido.detalles.reduce((acc, item) => acc + (item.det_precio * item.det_cantidad), 0);
      }
    }
  }

  ngOnInit() {}

  async procesarPago() {
    if (!this.pago.nombre || !this.pago.tarjeta || !this.pago.exp || !this.pago.cvv) {
      const toast = await this.toastCtrl.create({ 
        message: 'Por favor rellene toda la información requerida', 
        duration: 2000, 
        color: 'warning' 
      });
      await toast.present();
      return;
    }

    const toast = await this.toastCtrl.create({ 
      message: '¡Simulación de pago aprobada con éxito!', 
      duration: 2500, 
      color: 'success' 
    });
    await toast.present();
    this.router.navigate(['/principal']);
  }
}