export interface Ipedido{
    cli_id: number;
    usr_id: number;
    ped_estado: string;
    detalles: Idetalle [];
}

export interface Idetalle {
    id_producto: number;
    det_cantidad: number;
    det_precio: number;
}